// Copyright 2016 Google Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.google.codelabs.appauth;

import android.app.ActivityManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import net.openid.appauth.AuthState;
import net.openid.appauth.AuthorizationException;
import net.openid.appauth.AuthorizationRequest;
import net.openid.appauth.AuthorizationResponse;
import net.openid.appauth.AuthorizationService;
import net.openid.appauth.AuthorizationServiceConfiguration;
import net.openid.appauth.TokenResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.afollestad.materialdialogs.MaterialDialog.Builder;
import com.afollestad.materialdialogs.Theme;

import java.math.BigDecimal;

import static com.google.codelabs.appauth.MainApplication.LOG_TAG;

public class MainActivity extends AppCompatActivity {

  private static final String SHARED_PREFERENCES_NAME = "AuthStatePreference";
  private static final String AUTH_STATE = "AUTH_STATE";
  private static final String USED_INTENT = "USED_INTENT";

  MainApplication mMainApplication;

  // state
  public AuthState mAuthState;

  // views
  AppCompatButton mAuthorize;
  AppCompatButton mSignOut;
  private Button btStartService;
  private TextView tvText;
  public static TextView textView_labels;
  public static TextView textView_scores;
  public static TextView textView_label;
  public static TextView textView_score;
  public static TextView textview_latitudes;
  public static TextView textview_latitude;
  public static TextView textview_longitudes;
  public static TextView textview_longitude;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    mMainApplication = (MainApplication) getApplication();
    mAuthorize = (AppCompatButton) findViewById(R.id.authorize);
    mSignOut = (AppCompatButton) findViewById(R.id.signOut);

    btStartService = (Button) findViewById(R.id.btStartService);
    tvText = (TextView) findViewById(R.id.tvText);
    textView_labels = (TextView) findViewById(R.id.label);
    textView_scores = (TextView) findViewById(R.id.score);
    textView_label = (TextView) findViewById(R.id.label_text);
    textView_score = (TextView) findViewById(R.id.score_text);
    textview_latitudes = (TextView) findViewById(R.id.latitude);
    textview_latitude = (TextView) findViewById(R.id.latitude_text);
    textview_longitudes = (TextView) findViewById(R.id.longitude);
    textview_longitude = (TextView) findViewById(R.id.longitude_text);
    enableAutoStart();
    enablePostAuthorizationFlows();

    // wire click listeners
    mAuthorize.setOnClickListener(new AuthorizeListener());

    if (checkServiceRunning()) {
      btStartService.setText(getString(R.string.stop_service));
      tvText.setVisibility(View.VISIBLE);
    }
    btStartService.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        if (btStartService.getText().toString().equalsIgnoreCase(getString(R.string.start_service))) {
          enablePostAuthorizationFlows();
          Intent serviceIntent = new Intent(MainActivity.this, MyService.class);
          startService(serviceIntent);
          btStartService.setText(getString(R.string.stop_service));
          tvText.setVisibility(View.VISIBLE);
        } else {
          stopService(new Intent(MainActivity.this, MyService.class));
          btStartService.setText(getString(R.string.start_service));
          tvText.setVisibility(View.GONE);
        }
      }
    });
  }
  private void enableAutoStart() {
    for (Intent intent : Constants.AUTO_START_INTENTS) {
      if (getPackageManager().resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY) != null) {
        new Builder(this).title(R.string.enable_autostart)
                .content(R.string.ask_permission)
                .theme(Theme.LIGHT)
                .positiveText(getString(R.string.allow))
                .onPositive(new MaterialDialog.SingleButtonCallback() {
                  @Override
                  public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                    try {
                      for (Intent intent1 : Constants.AUTO_START_INTENTS)
                        if (getPackageManager().resolveActivity(intent1, PackageManager.MATCH_DEFAULT_ONLY)
                                != null) {
                          startActivity(intent1);
                          break;
                        }
                    } catch (Exception e) {
                      e.printStackTrace();
                    }
                  }
                }).show();
        break;
      }
    }
  }

  public boolean checkServiceRunning() {
    ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
    if (manager != null) {
      for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(
              Integer.MAX_VALUE)) {
        if (getString(R.string.my_service_name).equals(service.service.getClassName())) {
          return true;
        }
      }
    }
    return false;
  }

  @Override
  protected void onDestroy() {
    super.onDestroy();
  }

  @Override
  protected void onNewIntent(Intent intent) {
    checkIntent(intent);
  }

  private void checkIntent(@Nullable Intent intent) {
    if (intent != null) {
      String action = intent.getAction();
      switch (action) {
        case "com.google.codelabs.appauth.HANDLE_AUTHORIZATION_RESPONSE":
          if (!intent.hasExtra(USED_INTENT)) {
            handleAuthorizationResponse(intent);
            intent.putExtra(USED_INTENT, true);
          }
          break;
        default:
          // do nothing
      }
    }
  }

  @Override
  protected void onStart() {
    super.onStart();
    checkIntent(getIntent());
  }
  private void enablePostAuthorizationFlows() {
    mAuthState = restoreAuthState();
    if (mAuthState != null && mAuthState.isAuthorized()) {
      if (mSignOut.getVisibility() == View.GONE) {
        mSignOut.setVisibility(View.VISIBLE);
        mSignOut.setOnClickListener(new SignOutListener(this));
      }
    } else {
      //mMakeApiCall.setVisibility(View.GONE);
      mSignOut.setVisibility(View.GONE);
    }
  }

  /**
   * Exchanges the code, for the {@link TokenResponse}.
   *
   * @param intent represents the {@link Intent} from the Custom Tabs or the System Browser.
   */
  private void handleAuthorizationResponse(@NonNull Intent intent) {

    // code from the step 'Handle the Authorization Response' goes here.
    AuthorizationResponse response = AuthorizationResponse.fromIntent(intent);
    AuthorizationException error = AuthorizationException.fromIntent(intent);
    final AuthState authState = new AuthState(response, error);
    if (response != null) {
      Log.i(LOG_TAG, String.format("Handled Authorization Response %s ", authState.toJsonString()));
      AuthorizationService service = new AuthorizationService(this);
      service.performTokenRequest(response.createTokenExchangeRequest(), new AuthorizationService.TokenResponseCallback() {
        @Override
        public void onTokenRequestCompleted(@Nullable TokenResponse tokenResponse, @Nullable AuthorizationException exception) {
          if (exception != null) {
            Log.w(LOG_TAG, "Token Exchange failed", exception);
          } else {
            if (tokenResponse != null) {
              authState.update(tokenResponse, exception);
              persistAuthState(authState);
              Log.i(LOG_TAG, String.format("Token Response [ Access Token: %s, ID Token: %s ]", tokenResponse.accessToken, tokenResponse.idToken));
            }
          }
        }
      });
    }
  }

  private void persistAuthState(@NonNull AuthState authState) {
    getSharedPreferences(SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE).edit()
        .putString(AUTH_STATE, authState.toJsonString())
        .commit();
    //enablePostAuthorizationFlows();
  }

  private void clearAuthState() {
    getSharedPreferences(SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE)
        .edit()
        .remove(AUTH_STATE)
        .apply();
  }

  @Nullable
  private AuthState restoreAuthState() {
    String jsonString = getSharedPreferences(SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE)
        .getString(AUTH_STATE, null);
    if (!TextUtils.isEmpty(jsonString)) {
      try {
        return AuthState.fromJson(jsonString);
      } catch (JSONException jsonException) {
        // should never happen
      }
    }
    return null;
  }

  /**
   * Kicks off the authorization flow.
   */
  public static class AuthorizeListener implements Button.OnClickListener {
    @Override
    public void onClick(View view) {
      AuthorizationServiceConfiguration serviceConfiguration = new AuthorizationServiceConfiguration(
              Uri.parse("https://accounts.google.com/o/oauth2/v2/auth") /* auth endpoint */,
              Uri.parse("https://www.googleapis.com/oauth2/v4/token") /* token endpoint */
      );
      String clientId = "24455873356-4d1nvok294nasss4840k1v7ierh16q1f.apps.googleusercontent.com";
      Uri redirectUri = Uri.parse("com.google.codelabs.appauth:/oauth2callback");
      AuthorizationRequest.Builder builder = new AuthorizationRequest.Builder(
              serviceConfiguration,
              clientId,
              AuthorizationRequest.RESPONSE_TYPE_CODE,
              redirectUri
      );
      //builder.setScopes("profile");
      builder.setScopes("https://www.googleapis.com/auth/cloud-platform");
      AuthorizationRequest request = builder.build();
      // code from the step 'Create the Authorization Request',
      // and the step 'Perform the Authorization Request' goes here.
      AuthorizationService authorizationService = new AuthorizationService(view.getContext());
      String action = "com.google.codelabs.appauth.HANDLE_AUTHORIZATION_RESPONSE";
      Intent postAuthorizationIntent = new Intent(action);
      PendingIntent pendingIntent = PendingIntent.getActivity(view.getContext(), request.hashCode(), postAuthorizationIntent, 0);
      authorizationService.performAuthorizationRequest(request, pendingIntent);

    }
  }

  public static class SignOutListener implements Button.OnClickListener {

    private final MainActivity mMainActivity;

    public SignOutListener(@NonNull MainActivity mainActivity) {
      mMainActivity = mainActivity;
    }

    @Override
    public void onClick(View view) {
      mMainActivity.mAuthState = null;
      mMainActivity.clearAuthState();
      mMainActivity.enablePostAuthorizationFlows();
    }
  }

  public static class MakeApiCallListener{

    private final MyService mMainActivity;
    private AuthState mAuthState;
    private AuthorizationService mAuthorizationService;
    String sentence = null;
    private class AsyncTaskClass extends AsyncTask<String, Void, JSONObject>{

      protected AsyncTaskClass(String sentences){
        sentence = sentences;
      }
      @Override
      protected JSONObject doInBackground(String... tokens) {
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");
        JSONObject textsnippet = new JSONObject();
        try{
          textsnippet.put("content",sentence);
          textsnippet.put("mime_type", "text/plain");
        }catch(JSONException e){
          e.printStackTrace();
        }
        JSONObject text = new JSONObject();
        try{
          text.put("textSnippet", textsnippet);
        }catch (JSONException e){
          e.printStackTrace();
        }
        JSONObject payload = new JSONObject();
        try {
          payload.put("payload", text);
        }catch(JSONException e) {
          e.printStackTrace();
        }

        RequestBody body = RequestBody.create(JSON, payload.toString());
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url("https://automl.googleapis.com/v1/projects/myaiapplication/locations/us-central1/models/TCN6448833608999239680:predict")
                .addHeader("Authorization", String.format("Bearer %s", tokens[0]))
                .post(body)
                .build();

        try {
          Response response = client.newCall(request).execute();
          String jsonBody = response.body().string();
          Log.i(LOG_TAG, String.format("Response from AutoML api %s", jsonBody));
          return new JSONObject(jsonBody);
        } catch (Exception exception) {
          Log.w(LOG_TAG, exception);
        }
        return null;
      }
      @Override
      protected void onPostExecute(JSONObject response) {
        if (response != null){
          JSONArray jsonArray = null;
          Log.i(LOG_TAG, String.format("display name %s", sentence));
          try {
            jsonArray = response.getJSONArray("payload");
          }catch (JSONException e){
            e.printStackTrace();
          }
          String label = null;
          String score = null;
          for (int i = 0; i < jsonArray.length(); i++){
            JSONObject jsonObject1 = null;
            String jsonArray2 = null;
            JSONObject jsonObject2 = null;
            String jsonArray3 = null;
            try{
              jsonObject1 = jsonArray.getJSONObject(i);
              jsonArray2 = jsonObject1.getString("displayName");
              Log.i(LOG_TAG, String.format("display name %s", jsonArray2));
              jsonObject2 = jsonObject1.getJSONObject("classification");
              jsonArray3 = jsonObject2.getString("score");
              Log.i(LOG_TAG, String.format("score %s", jsonArray3));
              if(i == 0){
                label = jsonArray2;
                score = jsonArray3;
              }
              else if(BigDecimal.valueOf(Double.parseDouble(jsonArray3)).compareTo(BigDecimal.valueOf(Double.parseDouble(score))) == 1){
                label = jsonArray2;
                score = jsonArray3;
              }
            }catch (JSONException e){
              e.printStackTrace();
            }

          }
          GpsTracker g = new GpsTracker(mMainActivity);
          Location l = g.getLocation();
          double latitude = l.getLatitude();
          double longitude = l.getLongitude();
          textView_labels.setVisibility(View.VISIBLE);
          textView_scores.setVisibility(View.VISIBLE);
          textview_latitudes.setVisibility(View.VISIBLE);
          textview_longitudes.setVisibility(View.VISIBLE);
          textView_label.setText(label);
          textView_score.setText(score);
          textview_latitude.setText(String.valueOf(latitude));
          textview_longitude.setText(String.valueOf(longitude));
          textView_label.setVisibility(View.VISIBLE);
          textView_score.setVisibility(View.VISIBLE);
          textview_latitude.setVisibility(View.VISIBLE);
          textview_longitude.setVisibility(View.VISIBLE);
        }
      }
    }

    public MakeApiCallListener(@NonNull MyService mainActivity, @NonNull AuthState authState, @NonNull AuthorizationService authorizationService, final String sentence) {
      mMainActivity = mainActivity;
      mAuthState = authState;
      mAuthorizationService = authorizationService;
      if (mAuthState != null && mAuthState.isAuthorized()) {
        mAuthState.performActionWithFreshTokens(mAuthorizationService, new AuthState.AuthStateAction() {
          @Override
          public void execute(@Nullable String accessToken, @Nullable String idToken, @Nullable AuthorizationException exception) {
            AsyncTaskClass asyncTaskClass = new AsyncTaskClass(sentence);
            asyncTaskClass.execute(accessToken);
          }
        });
      }

    }
  }
}
