package com.google.codelabs.appauth.ui.animators;

public interface BarParamsAnimator {
    void start();
    void stop();
    void animate();
}
