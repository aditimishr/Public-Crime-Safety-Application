package com.google.codelabs.appauth;

public interface TextToSpeechCallback {
    void onStart();
    void onCompleted();
    void onError();
}
